import React from 'react'
import "./About.scss"
import { Header } from '../../components/Header'


export  function About() {
  return (
      <div>
          
    </div>
  )
}
