import {Color} from './Color'
export {Color}