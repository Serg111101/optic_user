import { Galery } from "./Galery";
export {Galery}
