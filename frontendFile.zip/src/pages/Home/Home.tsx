import "./Home.scss";
import { Galery } from "../../components/Galery";

export function Home() {

  return (
    <div className="home">
      
      <Galery />

    </div>
  )
}
  