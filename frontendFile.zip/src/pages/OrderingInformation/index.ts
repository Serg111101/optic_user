import { OrderingInformation } from "./OrderingInformation";
export default OrderingInformation