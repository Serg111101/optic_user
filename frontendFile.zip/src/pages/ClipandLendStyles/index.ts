import { ClipandLendStyles } from "./ClipandLendStyles";
export { ClipandLendStyles}
