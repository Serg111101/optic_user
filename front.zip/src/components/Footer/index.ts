import { Footer } from "./Footer";
export { Footer };
