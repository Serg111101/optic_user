import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { IUsps } from '../../models/model';
interface UspsState {
   loading: boolean;
   error:string;
   usps:IUsps[]
   create:IUsps[]
}

const initialState:UspsState = {
    loading: false,
    error:"",
    usps:[],
    create:[]
}

export const uspsSlice = createSlice({
  name: 'usps',
  initialState,
  reducers: {
    fetching(state){
        state.loading = true;
    },
    fetchSuccess(state,action: PayloadAction<IUsps[]>){
        state.loading = false;
        state.usps = action.payload;
        state.error = ''
    },
    fetchSuccess1(state,action: PayloadAction<IUsps[]>){
        state.loading = false;
        state.create = action.payload;
        state.error = ''
    },
    fetchError(state,action: PayloadAction<Error>){
        state.loading = false;
        state.error = action.payload.message
    }
  }
})

export const {  fetching, fetchSuccess, fetchSuccess1,fetchError } = uspsSlice.actions


export default uspsSlice.reducer