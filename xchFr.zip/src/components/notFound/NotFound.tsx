import './NotFound.scss'

export const NotFound = () => {
    

    return (
        <div className='NotFound'>
            
            {/* <nav classNameName="shelf">
                <a classNameName="book home-page" href='/'>Home page</a>
                <a classNameName="book about-us" href='/about'>About us</a>
                <a classNameName="book contact" href='/ClipandLendStyles'>Clip Styles</a>

                <span classNameName="book not-found"></span>

                <span classNameName="door left"></span>
                <span classNameName="door right"></span>

            </nav>
            <h1>Error 404</h1>
            <p>The page you're loking for can't be found</p> */}
            <div className="stars">
  <div className="cluster__1"></div>
  <div className="cluster__2"></div>
  <div className="cluster__3"></div>
</div>
        </div>
    )
}
