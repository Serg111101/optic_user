export interface IOrders {
    id: number;
    title: string;
    name: string;
    price: number;
    price1: number;
    img: string
}

export interface IUsps {
    id: number;
    title: string;
    name: string;
    price: number;
    price1: number;
    img: string
}


